#include<stdio.h>
#include<string.h>
char name[20];
int count=0,n,i,j;

struct find_rel{
char child[20];
char father[20];
}r[10];

void grandchild(char name[]){
for (j=0;j<10;j++){
if (strcmp(name,r[j].father)==0)
count++;
grandchild(r[j].child);
}
}

void main(){
	for (i=0;i<5;i++){
	scanf("%s",r[i].child);
	scanf("%s",r[i].father);
	}
	printf("Enter the persons name: \n");
	scanf("%s",name);
	
	for (i=0;i<10;i++){
	if (strcmp(name,r[i].father)==0)
	grandchild(r[i].child);
	}
	printf("%d",count);
}

